# AGENTS.md — hướng dẫn chung cho mọi agent AI của nhóm

> Cập nhật file này qua các phase (lịch sử git phải cho thấy điều đó). Ngắn gọn, có lệnh chạy thật.

## Lệnh
- Test: `PYTHONPATH=tests:. python3 -m unittest discover -s tests -v`
- Headless: `python3 -m chonoi.headless --mode gather|quan --seed 1 --ticks 600 --out out.jsonl`
- Chơi thử trên trình duyệt: `python3 -m chonoi.live --mode gather|quan` (mở địa chỉ in ra; WASD, E, Space, R)
- Test lát day Phase 2 trên PowerShell: `$env:PYTHONPATH='tests;.'; python3 -m unittest tests.test_day -v`.
- Benchmark v1.3 (cần Chrome/Chromium/Edge): `python3 -m chonoi.bench --seed 42 --duration 30 --out bench.json`; soak: `python3 -m chonoi.soak --seed 7 --days 10 --out soak.json`.
- Chạy day v1.1: `python3 -m chonoi.live --mode day --days 5` (Esc/P tạm dừng), `python3 -m chonoi.headless --mode day --days 1 --seed 1 --ticks 22200 --out out.jsonl`.

## Cấu trúc & quy ước
- (Starter Python là TÙY CHỌN; nhóm có thể dùng ngôn ngữ khác nếu giữ Test Contract.) Khung do giảng viên cấp: `chonoi/{headless,inputs,scenario,contract,rng,ids,jsonl,inventory,runner,live}.py` và `chonoi/web/`. Hạn chế sửa; nếu phải sửa thì báo cả nhóm và ghi lại lý do.
- Luật chơi của nhóm: `chonoi/sim/gather.py`, `chonoi/sim/quan.py` (tìm `TODO(nhóm)`).
- **Số liệu chỉ đọc từ `game.contract.json` / dữ liệu**, không hard-code trong luật.
- Mọi số ngẫu nhiên đi qua `Streams` (`chonoi/rng.py`); không dùng `random` toàn cục, không dùng đồng hồ hệ thống.
- Sắp danh sách thực thể bằng `ids.sort_by_id`; cấp id bằng `IdAllocator`.

## Nên tránh
- Không sửa `docs/contracts/`, `game.contract.json` (khóa contract) hoặc schema kho khi chưa báo cả nhóm (đổi hợp đồng ảnh hưởng mọi module).
- Không làm hỏng nhánh chính: trước khi đẩy, chạy test.
- Không bịa yêu cầu: chỗ mơ hồ thì ghi `docs/clarify.md` và hỏi PO.
- Không sửa test cho xanh khi luật sai; phải sửa luật hoặc ghi lý do đổi test trong commit.

## Quy tắc làm việc với agent
- Trước khi tạo thư mục, nói rõ tên/vị trí và mục đích cho người dùng. Thư mục tạm do tác vụ tạo chỉ để kiểm thử/chạy thử phải tự dọn sau khi xong, kể cả khi lỗi; không xóa thư mục có sẵn hoặc file test/bằng chứng cần bàn giao.
- Thành phụ trách client/ui trên nhánh `p1/ui`; lỗi luật gather/quán chuyển chủ module theo TEAM.md. Không stage/commit/push khi người dùng muốn tự commit.
- Phase 2: Thành phụ trách điều phối day/pause và UI trên `p2/day-ui`; dùng preset và Shop của Khánh, kế hoạch ngày và luật quán của Trà. Test vòng ngày gọi Shop thật, có thể rút ngắn ca bằng fixture.
- Test UI: `node --test tests/test_ui.js` (Node có sẵn, không cần npm install). Lệnh unittest chung cũng chạy test này khi có Node; thiếu Node phải báo skip.
- Phase 4: Thành làm cảnh báo/tương phản và đóng gói trên `p4/day-ui`; không đổi bench/soak/contract. Chụp proof bằng `python3 tools/proof_day_ui.py` (Chrome + Node 22+, hồ sơ tạm tự dọn). Integrator tạo ZIP bằng `git archive` từ tag bàn giao; không gắn tag/Release thay chủ nhiệm.
- Mỗi agent một việc rõ ràng (một lát). Cho agent đọc PRD/ticket đúng phase và hợp đồng kho trước.
- Agent làm xong phải chạy test và ghi kết quả vào mô tả commit hoặc `docs/proof/`; người đọc lại thay đổi trước khi đẩy.
- Sáng tạo thêm được khuyến khích nhưng phải tắt ở headless (xem README, mục "Tự do sáng tạo").

## Skills / hooks của nhóm
- [contract-review](docs/skills/contract-review.md): rà schema, thứ tự sự kiện và bàn giao giữa module.
- [phase-proof](docs/skills/phase-proof.md): ghi lệnh, kết quả và phạm vi kiểm chứng mỗi phase.
